#!/bin/bash
# make the file executable by typing "chmod +x backup.sh"

#if [ -d "./backupfiles" ]; then
#    rm -r "./backupfiles"
#fi

#if [ ! -d "./backupfiles" ]; then
#         mkdir "./backupfiles"
#         cp  . -r *  ./backupfiles 
#fi
<<COMMENT
#!/bin/bash

backup_dir="backupfiles_$(date +"%Y-%m-%d_%H-%M-%S")"

if [ -d "$backup_dir" ]; then
    echo "Error: Backup directory '$backup_dir' already exists." >&2
    exit 1
fi

repo_dir=$(git rev-parse --show-toplevel)

if [ -z "$repo_dir" ]; then
    echo "Error: Not in a Git repository." >&2
    exit 1
fi

mkdir "$backup_dir"

rsync -a --exclude="$backup_dir" "$repo_dir/" "$backup_dir/"

tar -czf "$backup_dir.tar.gz" "$backup_dir"

rm -rf "$backup_dir"
COMMENT


#!/bin/bash

# Set the name of the backup archive
BACKUP_FILENAME="backupfiles_$(date +%Y-%m-%d_%H-%M-%S).tar.gz"

# Set the path of the directory to back up
SOURCE_DIR="./"

# Set the path of the backup directory
BACKUP_DIR="./backup"

# Create the backup directory if it doesn't exist
if [ ! -d "$BACKUP_DIR" ]; then
  mkdir "$BACKUP_DIR"
fi

# Create the backup archive, excluding the backup directory
tar --exclude="./backupfiles" -czvf "$BACKUP_DIR/$BACKUP_FILENAME" "$SOURCE_DIR"
