from django.apps import AppConfig


class BestSellerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Best_seller'
