from django.apps import AppConfig


class HealthAndHouseHoldConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Health_and_house_hold'
