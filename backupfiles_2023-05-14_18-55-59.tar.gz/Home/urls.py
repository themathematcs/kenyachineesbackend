from django.conf import settings
from django.conf.urls.static import static
from django.contrib.auth import views as auth_views

from django.urls import path
from .forms import Loginform

from . import views

urlpatterns = [
    path('', views.index, name='index'),


    path('search/', views.search_items, name='search_items'),
    
    path('signup/', views.Signup, name='signup'),
    path('login/', auth_views.LoginView.as_view(template_name='Home/login.html', authentication_form=Loginform), name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('contact/', views.contact, name='contact'),
    path('Menue/', views.Menue, name='Menue'),
    path('Beauty/', views.Beauty, name='Beauty'),
    path('Best-seller/', views.Best_seller, name='Best_seller'),
    path('Electronics/', views.Electronics, name='Electronics'),
    path('Health-and-house-hold/', views.Health_and_house_hold, name='Health_and_house_hold'),
    path('Home-and-Kitchen/', views.Home_and_Kitchen, name='Home_and_Kitchen'),
    path('Men/', views.Men, name='Men'),
    path('pet-Suplies/', views.pet_Suplies, name='pet_Suplies'),
    path('Shop/', views.Shop, name='Shop'),
    path('sports/', views.sports, name='sports'),
    path('Women/', views.Women, name='Women'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
