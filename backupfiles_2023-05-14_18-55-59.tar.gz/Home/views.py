from django.shortcuts import render, redirect
from django.http import HttpResponse
from .forms import SignupForm
from django.contrib.auth import login, logout
from django.contrib import messages
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login, authenticate
from item.models import Category, Item
from django.urls import reverse


# Create your views here.
def index(request):
    return render(request, 'Home/index.html')

def contact(request):
    return render(request, 'Home/contact.html')

def Menue(request):
    items = Item.objects.filter(is_sold=False)[0:6]
    categories = Category.objects.all()
    return render(request, 'Home/Menue.html', {
        'categories': categories,
        'items': items,

    })


def Signup(request):
    form = SignupForm()
    if request.method == 'POST':
        form = SignupForm(request.POST)

        if form.is_valid():
            form.save()

            return redirect('/login/')
        
       # else:
         #   form = SignupForm()

    return render(request, 'Home/signup.html', {
        'form': form
    })

def logout_view(request):
    logout(request)
    return redirect(reverse('index'))

def Beauty(request):
    return render(request, 'Home/Beauty.html')

def Best_seller(request):
    render(request, 'Home/Best_seller.html')

def Electronics(request):
    return render(request, 'Home/Electronics.html')

def Health_and_house_hold(request):
    return render(request, 'Home/Health_and_house_hold.html')

def Home_and_Kitchen(request):
    render(request, 'Home/Home_and_Kitchen.html')

def Men(request):
    return render(request, 'Home/Men.html')

def pet_Suplies(request):
    return render(request, 'Home/pet_Suplies.html')

def Shop(request):
    return render(request, 'Home/Shop.html')

def sports(request):
    return render(request, 'Home/sports.html')

def Women(request):
    return render(request, 'Home/Women.html')



'''def search_items(request):
    query = request.GET.get('q')

    if query:
        items = Item.objects.filter(name__icontains=query, is_sold=False)
    else:
        items = Item.objects.filter(is_sold=False)

    categories = Category.objects.all()

    return render(request, 'Home/Menue.html', {
        'categories': categories,
        'items': items,
        'query': query,
    })
'''
def search_items(request):
    query = request.GET.get('q')

    if query:
        items = Item.objects.filter(name__icontains=query, is_sold=False)
    else:
        items = Item.objects.filter(is_sold=False)

    categories = Category.objects.all()

    if not items:
        message = f"No items found for query: '{query}'"
    else:
        message = ""

    return render(request, 'Home/Menue.html', {
        'categories': categories,
        'items': items,
        'query': query,
        'message': message,
    })
